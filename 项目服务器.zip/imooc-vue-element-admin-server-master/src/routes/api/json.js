module.exports = {
  success: true, // 成功状态
  code: 200, // 成功状态码
  data: null, // 返回数据
  message: 'success'
}
